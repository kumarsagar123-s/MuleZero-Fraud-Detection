from pathlib import Path
from fastapi import FastAPI
from fastapi.responses import FileResponse
from .database import *
from .demo_data import DEMO_TRANSACTIONS
from .graph_engine import analyze_graph
from .schemas import Transaction,AnalysisRequest
app=FastAPI(title='MuleZero API')
FRONTEND_FILE=Path(__file__).resolve().parents[2]/'frontend'/'index.html'
@app.on_event('startup')
def startup(): init_db()
@app.get('/')
def home(): return FileResponse(FRONTEND_FILE)
@app.get('/api/health')
def health(): return {'status':'ok','service':'MuleZero'}
@app.get('/api/transactions')
def transactions(): return {'transactions':get_transactions()}
@app.post('/api/demo/load')
def demo(): clear_transactions(); [insert_transaction(x) for x in DEMO_TRANSACTIONS]; return {'message':'Demo data loaded'}
@app.get('/api/graph')
def graph(): return analyze_graph(get_transactions())
@app.post('/api/analyze')
def analyze(req:AnalysisRequest): return analyze_graph([x.model_dump() for x in req.transactions])
