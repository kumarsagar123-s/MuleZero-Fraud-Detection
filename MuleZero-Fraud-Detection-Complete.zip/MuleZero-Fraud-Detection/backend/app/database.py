import sqlite3
from pathlib import Path
DB_PATH=Path('data/mulezero.db')
def get_connection():
    DB_PATH.parent.mkdir(parents=True,exist_ok=True); c=sqlite3.connect(DB_PATH); c.row_factory=sqlite3.Row; return c
def init_db():
    with get_connection() as c: c.execute('CREATE TABLE IF NOT EXISTS transactions (id INTEGER PRIMARY KEY AUTOINCREMENT,sender TEXT,receiver TEXT,amount REAL,timestamp TEXT)'); c.commit()
def insert_transaction(t):
    with get_connection() as c: c.execute('INSERT INTO transactions(sender,receiver,amount,timestamp) VALUES(?,?,?,?)',(t['sender'],t['receiver'],t['amount'],t.get('timestamp'))); c.commit()
def get_transactions():
    with get_connection() as c: return [dict(x) for x in c.execute('SELECT sender,receiver,amount,timestamp FROM transactions')]
def clear_transactions():
    with get_connection() as c: c.execute('DELETE FROM transactions'); c.commit()
