import networkx as nx

def build_graph(transactions):
    g = nx.DiGraph()
    for tx in transactions:
        s, r, amount = tx['sender'], tx['receiver'], float(tx['amount'])
        if g.has_edge(s, r):
            g[s][r]['amount'] += amount; g[s][r]['count'] += 1
        else:
            g.add_edge(s, r, amount=amount, count=1)
    return g

def find_fan_patterns(g):
    return [{'account': n, 'incoming_connections': g.in_degree(n), 'outgoing_connections': g.out_degree(n), 'reason': 'High fan-in or fan-out connectivity'} for n in g if g.in_degree(n) >= 3 or g.out_degree(n) >= 3]

def find_multi_hop_chains(g):
    out=[]
    for s in g:
        for t in g:
            if s == t: continue
            try: paths=nx.all_simple_paths(g,s,t,cutoff=5)
            except nx.NetworkXNoPath: continue
            for p in paths:
                if len(p)>=4: out.append({'path':p,'hops':len(p)-1,'reason':'Multi-hop movement across connected accounts'})
                if len(out)>=30: return out
    return out

def find_pass_through_accounts(g):
    return [{'account':n,'incoming_connections':g.in_degree(n),'outgoing_connections':g.out_degree(n),'reason':'Account receives and forwards funds'} for n in g if g.in_degree(n)>0 and g.out_degree(n)>0 and g.out_degree(n)/g.in_degree(n)>=.70]

def analyze_graph(transactions):
    g=build_graph(transactions); chains=find_multi_hop_chains(g); fans=find_fan_patterns(g); passes=find_pass_through_accounts(g)
    score=min(100,min(35,len(chains)*7)+min(25,len(fans)*5)+min(25,len(passes)*5)+(10 if g.number_of_nodes()>=5 else 0))
    level='HIGH' if score>=70 else 'MEDIUM' if score>=40 else 'LOW'
    reasons=[]
    if chains: reasons.append(f'{len(chains)} multi-hop chain(s) detected')
    if fans: reasons.append(f'{len(fans)} fan-in/fan-out pattern(s) detected')
    if passes: reasons.append(f'{len(passes)} pass-through account(s) detected')
    if g.number_of_nodes()>=5: reasons.append('Network contains at least five connected accounts')
    return {'summary':'Graph-based analysis of transaction relationships','risk_score':score,'risk_level':level,'reasons':reasons,'patterns':{'multi_hop_chains':chains,'fan_patterns':fans,'pass_through_accounts':passes},'graph':{'nodes':[{'id':n} for n in g],'edges':[{'source':s,'target':t,**d} for s,t,d in g.edges(data=True)]}}
