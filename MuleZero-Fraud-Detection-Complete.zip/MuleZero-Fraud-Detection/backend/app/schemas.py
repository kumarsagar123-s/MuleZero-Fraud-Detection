from pydantic import BaseModel,Field
from typing import Optional
class Transaction(BaseModel):
    sender:str; receiver:str; amount:float=Field(gt=0); timestamp:Optional[str]=None
class AnalysisRequest(BaseModel):
    transactions:list[Transaction]
