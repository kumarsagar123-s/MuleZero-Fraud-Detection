class InsightsAdapter:
    def analyze(self, transactions):
        return {'status':'prototype','message':'Configure the official iNSIGHTS API/SDK before production use.','signals':[]}
