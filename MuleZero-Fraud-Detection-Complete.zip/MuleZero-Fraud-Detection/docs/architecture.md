# MuleZero Architecture

```text
Transaction Data
      ↓
FastAPI + Python
      ↓
NetworkX Money-Flow Graph
      ↓
Graph Feature Extraction
      ↓
Multi-Hop / Fan-In / Fan-Out / Pass-Through Analysis
      ↓
Risk Scoring
      ↓
Explainable Risk Signals
      ↓
Dashboard / Investigation Alert
```
