# Research and Background References

1. Motie & Raahemi, “Financial Fraud Detection Using Graph Neural Networks: A Systematic Review” (2024). https://doi.org/10.1016/j.eswa.2023.122156
2. Cheng, Zou, Xiang & Jiang, “Graph Neural Networks for Financial Fraud Detection: A Review” (2025). https://doi.org/10.1007/s11704-024-40474-y
3. Tong & Shen, “Financial Transaction Fraud Detector Based on Imbalance Learning and Graph Neural Network” (2023). https://doi.org/10.1016/j.asoc.2023.110984
4. Qian & Tong, “Metapath-Guided Graph Neural Networks for Financial Fraud Detection” (2025). https://doi.org/10.1016/j.compeleceng.2025.110428
5. Mousavian & Miah, “Review of Artificial Intelligence-Based Applications for Money Laundering Detection” (2025). https://doi.org/10.1016/j.iswa.2025.200572
6. Zhou et al., “A User-Centered Explainable Artificial Intelligence Approach for Financial Fraud Detection” (2023). https://doi.org/10.1016/j.frl.2023.104309
7. BIS Innovation Hub, Project Aurora. https://www.bis.org/project/aurora
8. FATF, Digital Transformation of AML/CFT. https://www.fatf-gafi.org/en/publications/Digitaltransformation/Digital-transformation.html
