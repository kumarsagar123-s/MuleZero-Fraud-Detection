# Tech Stack

- Frontend: HTML, CSS, JavaScript, Cytoscape.js
- Backend: Python, FastAPI
- Graph Analysis: NetworkX
- Local Database: SQLite
- Future Database Schema: PostgreSQL
- Testing: Pytest
- Deployment: Docker, Docker Compose
- Competition Integration Boundary: iNSIGHTS adapter

The current risk engine is rule-based. The repository does not claim a trained PyTorch model, live gRPC service, or WebGL implementation that is not present in the code.
