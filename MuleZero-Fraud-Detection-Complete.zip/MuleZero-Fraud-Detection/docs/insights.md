# iNSIGHTS Integration

```text
Transaction Data
      ↓
iNSIGHTS Analysis / Processing
      ↓
Fraud Pattern Signal
      ↓
MuleZero Graph Analysis
      ↓
Risk Score
      ↓
Alert / Investigation
```

`backend/app/insights_adapter.py` is an integration boundary only. It does not invent an official iNSIGHTS API/SDK, authentication method or response format.
