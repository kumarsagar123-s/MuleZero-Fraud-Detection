# GitHub Submission

Suggested repository name: `MuleZero-Fraud-Detection`

After extracting this ZIP, upload the complete `MuleZero-Fraud-Detection` folder to GitHub.

```bash
git init
git add .
git commit -m "Initial MuleZero prototype"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/MuleZero-Fraud-Detection.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your actual GitHub username. Do not use the placeholder URL in the final PPT.
