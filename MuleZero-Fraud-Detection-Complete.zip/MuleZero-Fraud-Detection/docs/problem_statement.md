# Problem Statement

Traditional fraud detection can evaluate transactions individually, while suspicious money movement may be distributed across several connected accounts. Individual transactions can look normal even when the overall flow is suspicious.

MuleZero reconstructs transactions as a directed money-flow graph and checks for multi-hop movement, fan-in/fan-out connectivity, pass-through accounts and larger connected networks.

Short PPT statement: **Traditional fraud detection misses hidden money-mule networks.**
