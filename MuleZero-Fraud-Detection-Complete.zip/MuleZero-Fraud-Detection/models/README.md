# Models

Reserved for future trained model artifacts.

The current MuleZero prototype uses the transparent rule-based graph scoring engine in `backend/app/graph_engine.py`. No trained PyTorch model is included.
