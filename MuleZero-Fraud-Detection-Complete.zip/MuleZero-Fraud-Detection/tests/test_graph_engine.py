import sys
sys.path.insert(0,'backend')
from app.graph_engine import build_graph,analyze_graph
def test_graph():
 g=build_graph([{'sender':'A','receiver':'B','amount':100},{'sender':'B','receiver':'C','amount':90}]); assert g.number_of_nodes()==3 and g.number_of_edges()==2
def test_analysis():
 r=analyze_graph([{'sender':'A','receiver':'B','amount':100},{'sender':'B','receiver':'C','amount':90},{'sender':'C','receiver':'D','amount':80}]); assert 0<=r['risk_score']<=100 and r['risk_level'] in ['LOW','MEDIUM','HIGH']
