from backend.app.demo_data import DEMO_TRANSACTIONS
from backend.app.graph_engine import analyze_graph

def main():
    result = analyze_graph(DEMO_TRANSACTIONS)
    print("MuleZero Demo")
    print("Accounts:", len(result["graph"]["nodes"]))
    print("Connections:", len(result["graph"]["edges"]))
    print("Risk score:", result["risk_score"])
    print("Risk level:", result["risk_level"])
    for reason in result["reasons"]:
        print("-", reason)

if __name__ == "__main__":
    main()
